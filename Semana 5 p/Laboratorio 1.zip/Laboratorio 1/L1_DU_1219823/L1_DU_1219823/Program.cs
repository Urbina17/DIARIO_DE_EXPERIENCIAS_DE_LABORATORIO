﻿internal class Program
{
    private static void Main(string[] args)
    {
        Console.WriteLine("Ingrese su nombre: ");
            string Nombre = Console.ReadLine();
        Console.WriteLine("Hello, World! soy " + Nombre );
        Console.ReadKey();
        /* COMENTARIOS */
        Console.Write("Hola mundo");
        Console.Write("Soy " + Nombre);
        Console.ReadKey();
    }
}