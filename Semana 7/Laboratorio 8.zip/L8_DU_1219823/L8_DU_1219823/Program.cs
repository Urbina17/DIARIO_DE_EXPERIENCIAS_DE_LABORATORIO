﻿internal class Program
{
    private static void Main(string[] args)
    {
        Console.WriteLine("Laboratorio 8");
        int opcion;
        do
        {
            Console.WriteLine("Menú");
            Console.WriteLine("1. Sumatoria");
            Console.WriteLine("2. Tablas de multiplicar");
            Console.WriteLine("3. Numero perfecto");
            Console.WriteLine("4. Salir del programa");
            Console.Write("Ingrese la opción que desee: ");
            opcion = int.Parse(Console.ReadLine());
            switch (opcion)
            {
                case 1:
                    Console.Clear();
                    Console.WriteLine("Sumatoria");
                    Console.Write("Ingrese un número: ");
                    int num = int.Parse(Console.ReadLine());
                    int suma = 0;
                    for (int i = 1; i <= num; i++)
                    {
                        suma += i;
                    }
                    Console.WriteLine(" la suma es: " + suma);
                    Console.ReadKey();
                    Console.Clear();
                    break;
                case 2:
                    Console.Clear();
                    Console.WriteLine("Tablas de multiplicar");
                    int numero;
                    Console.Write("Ingresar un numero entre 1 y 10: ");
                    numero = int.Parse(Console.ReadLine());

                    if (numero >= 1 && numero <= 10)
                    {
                        Console.WriteLine("Tabla de multiplicar de: " + numero + ":");

                        for (int i = 1; i <= 10; i++)
                        {
                            Console.WriteLine(numero + " x " + i + " = " + (numero * i));
                        }
                    }
                    else
                    {
                        Console.WriteLine("El número ingresado esta fuera de rango.");
                    }
                    Console.ReadKey();
                    Console.Clear();
                    break;
                case 3:
                    Console.Clear();
                    Console.WriteLine("Numero perfecto");
                    Console.Write("Ingrese un número mayor a 0: ");
                    string input = Console.ReadLine();

                    int x;
                    if (!int.TryParse(input, out x))
                    {
                        Console.WriteLine("Error: Ingrese un número válido.");
                        return;
                    }

                    if (x == 0)
                    {
                        Console.WriteLine("Error: El número debe ser mayor a 0.");
                        return;
                    }

                    int sum = 0;
                    for (int i = 1; i < x; i++)
                    {
                        if (x % i == 0)
                        {
                            sum += i;
                        }
                    }

                    if (sum == x)
                    {
                        Console.WriteLine(x + " es un número perfecto.");
                    }
                    else
                    {
                        Console.WriteLine(x + " no es un número perfecto.");
                    }
                    Console.ReadKey();
                    Console.Clear();
                    break;
                case 4:
                    Console.Clear();
                    Console.WriteLine("Salio del programa");

                    Console.ReadKey();
                    Console.Clear();
                    break;
                default:
                    Console.Clear();
                    Console.WriteLine("Opción no valida");
                    Console.ReadKey();
                    Console.Clear();
                    break;
            }
        } while (opcion != 4);
        
    }
}