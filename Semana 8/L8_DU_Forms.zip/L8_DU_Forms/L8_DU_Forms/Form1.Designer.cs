﻿namespace L8_DU_Forms
{
    partial class Sumatoria
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lBl_Titulo = new System.Windows.Forms.Label();
            this.SELECCION = new System.Windows.Forms.GroupBox();
            this.cmb_seleccion = new System.Windows.Forms.ComboBox();
            this.BTN_SELECCION = new System.Windows.Forms.Button();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.labelresultadoperfecto = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.buttonperfecto = new System.Windows.Forms.Button();
            this.textBoxperfecto = new System.Windows.Forms.TextBox();
            this.labelperfecto = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.buttontablas = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.textBoxtablas = new System.Windows.Forms.TextBox();
            this.labeltablas = new System.Windows.Forms.Label();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.label3 = new System.Windows.Forms.Label();
            this.buttonsumatoria = new System.Windows.Forms.Button();
            this.labelresultadotablas = new System.Windows.Forms.Label();
            this.labelsumatoria = new System.Windows.Forms.Label();
            this.labelresultadototal = new System.Windows.Forms.Label();
            this.textBoxsumatoria = new System.Windows.Forms.TextBox();
            this.labelResultado = new System.Windows.Forms.Label();
            this.lBLIngreso_numero = new System.Windows.Forms.Label();
            this.tabDatos = new System.Windows.Forms.TabControl();
            this.SELECCION.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabDatos.SuspendLayout();
            this.SuspendLayout();
            // 
            // lBl_Titulo
            // 
            this.lBl_Titulo.AutoSize = true;
            this.lBl_Titulo.Font = new System.Drawing.Font("Times New Roman", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lBl_Titulo.Location = new System.Drawing.Point(50, 22);
            this.lBl_Titulo.Name = "lBl_Titulo";
            this.lBl_Titulo.Size = new System.Drawing.Size(259, 36);
            this.lBl_Titulo.TabIndex = 0;
            this.lBl_Titulo.Text = "LABORATORIO 8";
            // 
            // SELECCION
            // 
            this.SELECCION.Controls.Add(this.cmb_seleccion);
            this.SELECCION.Location = new System.Drawing.Point(50, 87);
            this.SELECCION.Name = "SELECCION";
            this.SELECCION.Size = new System.Drawing.Size(300, 150);
            this.SELECCION.TabIndex = 1;
            this.SELECCION.TabStop = false;
            this.SELECCION.Text = "Seleccionar";
            // 
            // cmb_seleccion
            // 
            this.cmb_seleccion.FormattingEnabled = true;
            this.cmb_seleccion.Items.AddRange(new object[] {
            "SUMATORIA",
            "TABLAS",
            "NUMERO PERFECTO"});
            this.cmb_seleccion.Location = new System.Drawing.Point(13, 27);
            this.cmb_seleccion.Name = "cmb_seleccion";
            this.cmb_seleccion.Size = new System.Drawing.Size(183, 33);
            this.cmb_seleccion.TabIndex = 0;
            this.cmb_seleccion.SelectedIndexChanged += new System.EventHandler(this.cmb_selección_SelectedIndexChanged);
            // 
            // BTN_SELECCION
            // 
            this.BTN_SELECCION.Location = new System.Drawing.Point(59, 247);
            this.BTN_SELECCION.Name = "BTN_SELECCION";
            this.BTN_SELECCION.Size = new System.Drawing.Size(111, 33);
            this.BTN_SELECCION.TabIndex = 2;
            this.BTN_SELECCION.Text = "Seleccionar";
            this.BTN_SELECCION.UseVisualStyleBackColor = true;
            this.BTN_SELECCION.Click += new System.EventHandler(this.BTN_SELECCION_Click);
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.labelresultadoperfecto);
            this.tabPage3.Controls.Add(this.label2);
            this.tabPage3.Controls.Add(this.buttonperfecto);
            this.tabPage3.Controls.Add(this.textBoxperfecto);
            this.tabPage3.Controls.Add(this.labelperfecto);
            this.tabPage3.Location = new System.Drawing.Point(4, 34);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(385, 249);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Numero perfecto";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // labelresultadoperfecto
            // 
            this.labelresultadoperfecto.AutoSize = true;
            this.labelresultadoperfecto.Location = new System.Drawing.Point(119, 95);
            this.labelresultadoperfecto.Name = "labelresultadoperfecto";
            this.labelresultadoperfecto.Size = new System.Drawing.Size(0, 25);
            this.labelresultadoperfecto.TabIndex = 4;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(26, 92);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(90, 25);
            this.label2.TabIndex = 3;
            this.label2.Text = "Resultado";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // buttonperfecto
            // 
            this.buttonperfecto.Location = new System.Drawing.Point(151, 182);
            this.buttonperfecto.Name = "buttonperfecto";
            this.buttonperfecto.Size = new System.Drawing.Size(111, 33);
            this.buttonperfecto.TabIndex = 2;
            this.buttonperfecto.Text = "Ejecutar";
            this.buttonperfecto.UseVisualStyleBackColor = true;
            this.buttonperfecto.Click += new System.EventHandler(this.buttonperfecto_Click);
            // 
            // textBoxperfecto
            // 
            this.textBoxperfecto.Location = new System.Drawing.Point(26, 48);
            this.textBoxperfecto.Name = "textBoxperfecto";
            this.textBoxperfecto.Size = new System.Drawing.Size(150, 31);
            this.textBoxperfecto.TabIndex = 1;
            // 
            // labelperfecto
            // 
            this.labelperfecto.AutoSize = true;
            this.labelperfecto.Location = new System.Drawing.Point(17, 17);
            this.labelperfecto.Name = "labelperfecto";
            this.labelperfecto.Size = new System.Drawing.Size(247, 25);
            this.labelperfecto.TabIndex = 0;
            this.labelperfecto.Text = "Ingrese un numero mayor a 0";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.buttontablas);
            this.tabPage2.Controls.Add(this.label1);
            this.tabPage2.Controls.Add(this.textBoxtablas);
            this.tabPage2.Controls.Add(this.labeltablas);
            this.tabPage2.Location = new System.Drawing.Point(4, 34);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3, 3, 3, 3);
            this.tabPage2.Size = new System.Drawing.Size(385, 249);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Tablas";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // buttontablas
            // 
            this.buttontablas.Location = new System.Drawing.Point(206, 52);
            this.buttontablas.Name = "buttontablas";
            this.buttontablas.Size = new System.Drawing.Size(111, 33);
            this.buttontablas.TabIndex = 3;
            this.buttontablas.Text = "Ejecutar";
            this.buttontablas.UseVisualStyleBackColor = true;
            this.buttontablas.Click += new System.EventHandler(this.buttontablas_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(26, 102);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(90, 25);
            this.label1.TabIndex = 2;
            this.label1.Text = "Resultado";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // textBoxtablas
            // 
            this.textBoxtablas.Location = new System.Drawing.Point(26, 52);
            this.textBoxtablas.Name = "textBoxtablas";
            this.textBoxtablas.Size = new System.Drawing.Size(150, 31);
            this.textBoxtablas.TabIndex = 1;
            // 
            // labeltablas
            // 
            this.labeltablas.AutoSize = true;
            this.labeltablas.Location = new System.Drawing.Point(14, 15);
            this.labeltablas.Name = "labeltablas";
            this.labeltablas.Size = new System.Drawing.Size(241, 25);
            this.labeltablas.TabIndex = 0;
            this.labeltablas.Text = "Ingrese un numero de 1 a 10";
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.buttonsumatoria);
            this.tabPage1.Controls.Add(this.labelresultadotablas);
            this.tabPage1.Controls.Add(this.labelsumatoria);
            this.tabPage1.Controls.Add(this.labelresultadototal);
            this.tabPage1.Controls.Add(this.textBoxsumatoria);
            this.tabPage1.Controls.Add(this.labelResultado);
            this.tabPage1.Controls.Add(this.lBLIngreso_numero);
            this.tabPage1.Location = new System.Drawing.Point(4, 34);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3, 3, 3, 3);
            this.tabPage1.Size = new System.Drawing.Size(385, 429);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Sumatoria";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(114, 75);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(0, 25);
            this.label3.TabIndex = 7;
            // 
            // buttonsumatoria
            // 
            this.buttonsumatoria.Location = new System.Drawing.Point(186, 193);
            this.buttonsumatoria.Name = "buttonsumatoria";
            this.buttonsumatoria.Size = new System.Drawing.Size(111, 33);
            this.buttonsumatoria.TabIndex = 6;
            this.buttonsumatoria.Text = "Ejecutar";
            this.buttonsumatoria.UseVisualStyleBackColor = true;
            this.buttonsumatoria.Click += new System.EventHandler(this.buttonsumatoria_Click);
            // 
            // labelresultadotablas
            // 
            this.labelresultadotablas.AutoSize = true;
            this.labelresultadotablas.Location = new System.Drawing.Point(23, 110);
            this.labelresultadotablas.Name = "labelresultadotablas";
            this.labelresultadotablas.Size = new System.Drawing.Size(0, 25);
            this.labelresultadotablas.TabIndex = 5;
            // 
            // labelsumatoria
            // 
            this.labelsumatoria.AutoSize = true;
            this.labelsumatoria.Location = new System.Drawing.Point(127, 135);
            this.labelsumatoria.Name = "labelsumatoria";
            this.labelsumatoria.Size = new System.Drawing.Size(0, 25);
            this.labelsumatoria.TabIndex = 4;
            // 
            // labelresultadototal
            // 
            this.labelresultadototal.AutoSize = true;
            this.labelresultadototal.Location = new System.Drawing.Point(186, 72);
            this.labelresultadototal.Name = "labelresultadototal";
            this.labelresultadototal.Size = new System.Drawing.Size(0, 25);
            this.labelresultadototal.TabIndex = 3;
            // 
            // textBoxsumatoria
            // 
            this.textBoxsumatoria.Location = new System.Drawing.Point(186, 38);
            this.textBoxsumatoria.Name = "textBoxsumatoria";
            this.textBoxsumatoria.Size = new System.Drawing.Size(150, 31);
            this.textBoxsumatoria.TabIndex = 2;
            this.textBoxsumatoria.TextChanged += new System.EventHandler(this.textBoxnumero_TextChanged);
            // 
            // labelResultado
            // 
            this.labelResultado.AutoSize = true;
            this.labelResultado.Location = new System.Drawing.Point(16, 72);
            this.labelResultado.Name = "labelResultado";
            this.labelResultado.Size = new System.Drawing.Size(90, 25);
            this.labelResultado.TabIndex = 1;
            this.labelResultado.Text = "Resultado";
            // 
            // lBLIngreso_numero
            // 
            this.lBLIngreso_numero.AutoSize = true;
            this.lBLIngreso_numero.Location = new System.Drawing.Point(16, 33);
            this.lBLIngreso_numero.Name = "lBLIngreso_numero";
            this.lBLIngreso_numero.Size = new System.Drawing.Size(162, 25);
            this.lBLIngreso_numero.TabIndex = 0;
            this.lBLIngreso_numero.Text = "Ingrese un numero";
            // 
            // tabDatos
            // 
            this.tabDatos.Controls.Add(this.tabPage1);
            this.tabDatos.Controls.Add(this.tabPage2);
            this.tabDatos.Controls.Add(this.tabPage3);
            this.tabDatos.Location = new System.Drawing.Point(371, 87);
            this.tabDatos.Name = "tabDatos";
            this.tabDatos.SelectedIndex = 0;
            this.tabDatos.Size = new System.Drawing.Size(393, 467);
            this.tabDatos.TabIndex = 3;
            // 
            // Sumatoria
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1137, 668);
            this.Controls.Add(this.tabDatos);
            this.Controls.Add(this.BTN_SELECCION);
            this.Controls.Add(this.SELECCION);
            this.Controls.Add(this.lBl_Titulo);
            this.Name = "Sumatoria";
            this.Text = "LABORATORIO 8";
            this.SELECCION.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabDatos.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label lBl_Titulo;
        private GroupBox SELECCION;
        private ComboBox cmb_seleccion;
        private Button BTN_SELECCION;
        private TabPage tabPage3;
        private TabPage tabPage2;
        private TabPage tabPage1;
        private Label labelresultadototal;
        private TextBox textBoxsumatoria;
        private Label labelResultado;
        private Label lBLIngreso_numero;
        private TabControl tabDatos;
        private Label labelsumatoria;
        private Label labeltablas;
        private Label label1;
        private TextBox textBoxtablas;
        private Label labelresultadotablas;
        private Button buttonsumatoria;
        private Button buttontablas;
        private Label label2;
        private Button buttonperfecto;
        private TextBox textBoxperfecto;
        private Label labelperfecto;
        private Label labelresultadoperfecto;
        private Label label3;
    }
}