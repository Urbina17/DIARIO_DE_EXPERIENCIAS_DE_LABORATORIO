namespace L8_DU_Forms
{
    public partial class Sumatoria : Form
    {
        public Sumatoria()
        {
            InitializeComponent();
        }

        private void cmb_selecci�n_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch(cmb_seleccion.SelectedIndex)
            {
                case 0:
                    MessageBox.Show("Selecciono sumatoria");
                    tabDatos.SelectedTab = tabPage1;
                    break;
                case 1:
                    MessageBox.Show("Selecciono multilplicacion");
                    tabDatos.SelectedTab = tabPage2;
                    break;
                case 2:
                    MessageBox.Show("Selecciono numero perfecto");
                    tabDatos.SelectedTab = tabPage3;
                    break;
            }
        }
        
        private void textBoxnumero_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void BTN_SELECCION_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void buttonsumatoria_Click(object sender, EventArgs e)
        {
            int num = Convert.ToInt32(textBoxsumatoria.Text);
            int suma = 0;
            for (int i = 1; i <= num; i++)
            {
                suma += i;
            }
            labelsumatoria.Text = suma.ToString();
        }

        private void buttontablas_Click(object sender, EventArgs e)
        {
            int numero = Convert.ToInt32(textBoxtablas.Text);
            if (numero >= 1 && numero <= 10)
            {
                labeltablas.Text = ("Tabla de multiplicar de: " + numero + ":");
                for (int i = 1; i <= 10; i++)
                {
                    label1.Text += ("\n"+numero + " x " + i + " = " + (numero * i));
                }
            }
            else
            {
                label1.Text = ("El numero esta fuera de rango");
            }
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void buttonperfecto_Click(object sender, EventArgs e)
        {
            string input = Convert.ToString(textBoxperfecto.Text);
            int x;
            if (!int.TryParse(input, out x))
            {
                labelresultadoperfecto.Text = ("Error: Ingrese un n�mero v�lido.");
                return;
            }

            if (x == 0)
            {
                labelresultadoperfecto.Text =("Error: El n�mero debe ser mayor a 0.");
                return;
            }

            int sum = 0;
            for (int i = 1; i < x; i++)
            {
                if (x % i == 0)
                {
                    sum += i;
                }
            }

            if (sum == x)
            {
                labelresultadoperfecto.Text = (x + " es un n�mero perfecto.");
            }
            else
            {
                labelresultadoperfecto.Text = (x + " no es un n�mero perfecto.");
            }
        }
    }
}