﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab10_DU_1219823
{
    internal class Circulo
    {
        private double radio;

        public Circulo(double r)
        {
            radio = r;
        }

        private double ObtenerPerimetro()
        {
            double perimetro = 2 * Math.PI * radio;
            return perimetro;
        }

        private double ObtenerArea()
        {
            double area = Math.PI * Math.Pow(radio, 2);
            return area;
        }

        private double ObtenerVolumen()
        {
            double volumen = (4.0 / 3.0) * Math.PI * Math.Pow(radio, 3);
            return volumen;
        }

        public void CalcularGeometria(ref double unPerimetro, ref double unArea, ref double unVolumen)
        {
            unPerimetro = ObtenerPerimetro();
            unArea = ObtenerArea();
            unVolumen = ObtenerVolumen();
        }
    }
}
