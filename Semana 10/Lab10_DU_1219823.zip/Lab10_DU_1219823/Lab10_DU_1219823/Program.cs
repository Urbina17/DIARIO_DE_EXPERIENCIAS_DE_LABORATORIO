﻿using Lab10_DU_1219823;

internal class Program
{
    private static void Main(string[] args)
    {
        Console.Write("Ingrese el radio del circulo: ");
        double radio = double.Parse(Console.ReadLine());

        Circulo objCirculo = new Circulo(radio);

        double perimetro = 0;
        double area = 0; 
        double volumen = 0;
        objCirculo.CalcularGeometria(ref perimetro, ref area, ref volumen);

        Console.WriteLine("Perimetro: " + perimetro);
        Console.WriteLine("Area: " + area);
        Console.WriteLine("Volumen: " + volumen);
    }
}